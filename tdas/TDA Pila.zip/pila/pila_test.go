package pila_test

import (
	TDAPila "tdas/pila"
	"testing"

	"fmt"

	"github.com/stretchr/testify/require"
)

// TestPilaVacia verifica los puntos:
// 1)Se pueda crear una Pila vacía, y ésta se comporta como tal.
// 4)Condición de borde: comprobar que una pila vacía se comporte como recién creada.
// 5)Condición de borde: las acciones para desapilar y ver tope de una pila recién creada son inválidas.
// 6)Condición de borde: la acción para ver si una pila recién creada está vacía es verdadero.
// 7)Condición de borde: las acciones para desapilar y ver el tope de una pila a la que se le apiló y desapiló hasta estar vacía son inválidas.

func TestPilaVacia(t *testing.T) {
	pila := TDAPila.CrearPilaDinamica[int]()
	require.True(t, pila.EstaVacia())
	require.PanicsWithValue(t, "La pila esta vacia", func() { pila.VerTope() })
	require.PanicsWithValue(t, "La pila esta vacia", func() { pila.Desapilar() })

	for i := 0; i < 100; i++ {
		pila.Apilar(i)
		require.False(t, pila.EstaVacia())
		require.Equal(t, i, pila.VerTope())
	}
	for i := 99; i >= 0; i-- {
		require.Equal(t, i, pila.Desapilar())
		if i > 0 {
			require.False(t, pila.EstaVacia())
		}
	}
	require.True(t, pila.EstaVacia())
	require.PanicsWithValue(t, "La pila esta vacia", func() { pila.VerTope() })
	require.PanicsWithValue(t, "La pila esta vacia", func() { pila.Desapilar() })
}

// TestPilaApilarDesapilarInts y TestPilaApilarDesapilarStrings verifican los puntos:
// 2)Se puedan apilar elementos, que al desapilarlos se mantenga el invariante de pila (que esta es LIFO). Probar con elementos diferentes, y ver que salgan en el orden deseado.
// 3)Prueba de volumen: Se pueden apilar muchos elementos (1.000, 10.000 elementos, o el volumen que corresponda): hacer crecer la pila, y desapilar elementos hasta que esté vacía, comprobando que siempre cumpla el invariante. Recordar no apilar siempre lo mismo, validar que se cumpla siempre que el tope de la pila sea el correcto paso a paso, y que el nuevo tope después de cada desapilar también sea el correcto.
// 8)Probar apilar diferentes tipos de datos: probar con una pila de enteros, con una pila de cadenas, etc…

func TestPilaApilarDesapilarInts(t *testing.T) {
	pila := TDAPila.CrearPilaDinamica[int]()
	for i := 0; i < 10000; i++ {
		pila.Apilar(i)
		require.Equal(t, i, pila.VerTope())
	}
	for i := 9999; i >= 0; i-- {
		require.Equal(t, i, pila.Desapilar())
		if i > 0 {
			require.Equal(t, i-1, pila.VerTope())
		}
	}
	require.True(t, pila.EstaVacia())
}

func TestPilaApilarDesapilarStrings(t *testing.T) {
	pila := TDAPila.CrearPilaDinamica[string]()
	for i := 0; i < 10000; i++ {
		pila.Apilar(fmt.Sprintf("string%d", i))
		require.Equal(t, fmt.Sprintf("string%d", i), pila.VerTope())
	}
	for i := 9999; i >= 0; i-- {
		require.Equal(t, fmt.Sprintf("string%d", i), pila.Desapilar())
		if i > 0 {
			require.Equal(t, fmt.Sprintf("string%d", i-1), pila.VerTope())
		}
	}
	require.True(t, pila.EstaVacia())
}
