package pila

/* Definición del struct pila proporcionado por la cátedra. */

type pilaDinamica[T any] struct {
	datos    []T
	cantidad int
}

func CrearPilaDinamica[T any]() Pila[T] {
	return &pilaDinamica[T]{datos: make([]T, 10)}
}

func (p *pilaDinamica[T]) EstaVacia() bool {
	return p.cantidad == 0
}

func (p *pilaDinamica[T]) VerTope() T {
	if p.EstaVacia() {
		panic("La pila esta vacia")
	}
	return p.datos[p.cantidad-1]
}

func (p *pilaDinamica[T]) Apilar(valor T) {
	if p.cantidad == len(p.datos) {
		p.redimensionar(len(p.datos) * 2)
	}
	p.datos[p.cantidad] = valor
	p.cantidad++
}

func (p *pilaDinamica[T]) Desapilar() T {
	if p.EstaVacia() {
		panic("La pila esta vacia")
	}
	valorDesapilado := p.datos[p.cantidad-1]
	p.cantidad--
	if p.cantidad <= len(p.datos)/4 && len(p.datos) > 10 {
		p.redimensionar(len(p.datos) / 2)
	}
	return valorDesapilado
}

func (p *pilaDinamica[T]) redimensionar(tam int) {
	nuevoSlice := make([]T, tam)
	copy(nuevoSlice, p.datos[:p.cantidad])
	p.datos = nuevoSlice
}
